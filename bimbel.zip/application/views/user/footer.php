<script src="<?= base_url('aset/js/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('aset/js/alert/sweetalert2.all.min.js') ?>"></script>
<script src="<?= base_url('aset/js/style.min.js') ?>"></script>

</body>

</html>