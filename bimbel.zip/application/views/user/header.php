<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?= base_url('aset/css/bootstrap.min.css') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@900&family=Dosis:wght@700&family=Merriweather:ital,wght@1,900&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="<?= base_url('aset/css/user.css') ?>">
    <link rel="shortcut icon" href="<?php echo base_url('aset/img/logo.png') ?>">
        <title>Hasil Perhtungan</title>
</head>

<body style=" background: rgb(104,176,171);
background: linear-gradient(171deg, rgba(104,176,171,1) 15%, rgba(143,192,169,1) 58%, rgba(200,213,185,1) 50%); ">